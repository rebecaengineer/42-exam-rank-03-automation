#ifndef N_QUEENS_H
# define N_QUEENS_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#endif