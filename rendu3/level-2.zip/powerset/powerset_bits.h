#ifndef POWERSET_BITS_H
# define POWERSET_BITS_H

#include <stdio.h>
#include <stdlib.h>

#endif