#ifndef POWERSET_H
#define POWERSET_H


#include <stdio.h>
#include <stdlib.h>


#endif