#ifndef PERMUTATIONS_COMENTADA_H
# define PERMUTATIONS_COMENTADA_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void	perm(int *cnt, int n, int depth, char *buf);

#endif